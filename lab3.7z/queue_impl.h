#ifndef QUEUE_IMPL_H
#define QUEUE_IMPL_H

template <typename T>
void Queue<T>::push(T t) {
    // TODO
}

template <typename T>
void Queue<T>::pop() {
    // TODO
}

template <typename T>
T &Queue<T>::front() {
    // TODO
}

template <typename T>
bool Queue<T>::empty() const {
    // TODO
}

template <typename T>
size_t Queue<T>::size() const {
    // TODO
}
#endif  // QUEUE_IMPL_H
