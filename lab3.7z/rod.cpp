#include "rod.h"
#include <cstddef>

Rod::Rod(const int capacity, const int id) : /* TODO */ { }

bool Rod::push(const Disk d) {
    // TODO
}

const Disk &Rod::top() {
    // TODO
}

void Rod::pop() {
    // TODO
}

size_t Rod::size() const {
    // TODO
}

bool Rod::empty() const {
    // TODO
}
bool Rod::full() const {
    // TODO
}
void Rod::draw(Canvas &canvas) {
    // TODO
}
