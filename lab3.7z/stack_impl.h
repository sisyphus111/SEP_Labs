#ifndef STACK_IMPL_H
#define STACK_IMPL_H
#include <cassert>

template <typename T>
void Stack<T>::push(T t) {
    // TODO
}

template <typename T>
void Stack<T>::pop() {
    // TODO
}

template <typename T>
T &Stack<T>::top() {
    // TODO
}

template <typename T>
bool Stack<T>::empty() const {
    // TODO
}

template <typename T>
size_t Stack<T>::size() const {
    // TODO
}

#endif  // STACK_IMPL_H
