#include "lexicon.h"

int main() {
  // TODO
  return 0;
}
