#include <iostream>
#include "Buffer.h"

//TODO: your code here
//implement the functions in Buffer

Buffer::Buffer() {}

Buffer::~Buffer() {}

void Buffer::writeToFile(const string &filename) const {}

void Buffer::showLines(int from, int to) const {}

void Buffer::deleteLines(int from, int to){}

void Buffer::insertLine(const string &text){}

void Buffer::appendLine(const string &text){}

const string &Buffer::moveToLine(int idx) const { }

// for test, Don't modify
static void* aPtr = nullptr;
static void* bPtr = nullptr;

void Buffer::printAddr(int idx) const {

    int curLineNo = 1;
    Line *curLine = headLine;
    while (curLineNo < idx) {
        curLineNo += 1;
        curLine = curLine->next;
    }
    
    std::cout << idx << ":" << curLine << std::endl;
}

void Buffer::loadAddr2(int one, int another) const {
    if (one == another)
        return;

    int first = std::min(one, another);
    int second = std::max(one, another);

    Line *firstLine = nullptr, *secondLine = nullptr;

    int curLineNo = 1;
    Line *curLine = headLine;
    while (curLineNo <= second) {
        if (curLineNo == first)
            firstLine = curLine;
        if (curLineNo == second)
            secondLine = curLine;

        curLineNo += 1;
        curLine = curLine->next;
    }

    if (firstLine && secondLine) {
        aPtr = (void *)firstLine;
        bPtr = (void *)secondLine;
    }
}

void Buffer::testSwap(int one, int another) const {

    if (one == another)
        return;

    int first = std::min(one, another);
    int second = std::max(one, another);

    Line *firstLine = nullptr, *secondLine = nullptr;

    int curLineNo = 1;
    Line *curLine = headLine;
    while (curLineNo <= second) {
        if (curLineNo == first)
            firstLine = curLine;
        if (curLineNo == second)
            secondLine = curLine;

        curLineNo += 1;
        curLine = curLine->next;
    }

    if (firstLine && secondLine) {
        if (aPtr == secondLine && bPtr == firstLine)
            std::cout << "Swap 2 Nodes successfully!" << std::endl;
        else
            std::cout << "Swap 2 Nodes failed!" << std::endl;
        aPtr = nullptr;
        bPtr = nullptr;
    }
}