#include "Editor.h"

int main()
{
    Editor ed;
    ed.run();
    return 0;
}